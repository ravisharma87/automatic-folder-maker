foldermaker software\dist\foldermakersoftware\foldermakersoftware.exe


1:make folders
2:you will get a .bat file in the same folder where exe is there
3:copy that bat file and paste where you want to make folders
4:run that .bat file and folders will be created
